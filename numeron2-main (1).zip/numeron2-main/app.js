const play = document.getElementById("play-button")

play.onclick = () => {
    location.href = "./game.html"
}